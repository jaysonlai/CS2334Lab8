public enum Shape{
	THIMBLE,
	BOOT, 
	RACECAR;
	
	@Override
	
	public String toString() {
		return this.name().toLowerCase();
	}

	}